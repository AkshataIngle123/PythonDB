import pymongo
client=pymongo.MongoClient("mongodb://localhost:27017")
try:
    client=pymongo.MongoClient("mongodb://localhost:27017")
    db=client["office"]
    coll=db["workers"]
    id=int(input('Enter Employee ID: '))
    qr={}
    qr["_id"]=id

    chval={}
    nesalary=int(input('Enter New Salary of Employee: '))
    chval["salary"]=nesalary

    upd={"$set":chval}

    coll.update_one(qr,upd)

    print('Employee data updated...')

except:
    print('unable to update the data')
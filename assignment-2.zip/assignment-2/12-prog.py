import pymongo
client=pymongo.MongoClient("mongodb://localhost:27017")
try:
    client=pymongo.MongoClient("mongodb://localhost:27017")
    db=client["office"]
    coll=db["workers"]
    sal=input('Enter Salary of Employee: ')
    for doc in coll.find({"salary":{"$gt":sal}}):
        print(doc)
    
except Exception as e:
    print(e)

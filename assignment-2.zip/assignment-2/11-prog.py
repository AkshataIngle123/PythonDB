import pymongo
client=pymongo.MongoClient("mongodb://localhost:27017")
try:
    client=pymongo.MongoClient("mongodb://localhost:27017")
    db=client["office"]
    coll=db["workers"]
    
    qr={}
    id=int(input('Enter Employee ID: '))
    qr["_id"]=id
    doc={}
    for doc in coll.find(qr):
        print("\nInformation: ")
        print("-"*30)
        print("id            : ",doc["_id"])
        print("name          : ",doc["empnm"])
        print("department    : ",doc["dept"])
        print("post          : ",doc["post"])
        print("city          : ",doc["city"])
        print("salary        : ",doc["salary"])
        print("mobile        : ",doc["mobile"])
        print("email         : ",doc["email"])
        print("\n")
    ans=input("Do you want to delete (y/n): ")
    if(ans.lower()=="y"):
        recover.insert_one(doc)
        coll.delete_one(qr)
        print('account deleted successfully')
    else:
        print('record not deleted')
    

except Exception as e:
    print('Invalid id !')
    print(e)

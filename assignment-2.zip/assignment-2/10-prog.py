import pymongo
client=pymongo.MongoClient("mongodb://localhost:27017")
try:
    client=pymongo.MongoClient("mongodb://localhost:27017")
    db=client["office"]
    coll=db["workers"]

    id=int(input('Enter Employee ID: '))
    qr={}
    qr["_id"]=id

    city=input('Enter employee city: ')
    ctval={}
    ctval["city"]=city

    dept=input('Enter employee department: ')
    deval={}
    deval["dept"]=dept

    upd={"$set":ctval}
    ab={"$set":deval}
    
    coll.update_one(qr,upd)
    coll.update_one(qr,ab)

    print('Employee data updated successfully..')

except:
    print('Unable to update the data')

    

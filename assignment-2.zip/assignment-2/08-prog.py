import pymongo
client=pymongo.MongoClient("mongodb://localhost:27017")
try:
    client=pymongo.MongoClient("mongodb://localhost:27017")
    db=client["office"]
    coll=db["workers"]
    dept=input('Enter department name: ')
    qr={}
    qr["dept"]=dept

    for doc in coll.find(qr):
        print(doc)

except:
    print('unable to show the data')
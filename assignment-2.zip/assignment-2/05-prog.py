import pymongo
client=pymongo.MongoClient("mongodb://27017")

try:
    client=pymongo.MongoClient("mongodb://localhost:27017")
    db=client["office"]
    coll=db["workers"]
    dic={}
    id=int(input('Enter Employee ID: '))
    empnm=input('Enter Employee name: ')
    dept=input('Enter Department: ')
    post=input('Enter Employee Post: ')
    city=input('Enter City of Employee: ')
    salary=int(input('Enter Salary of Employee: '))
    mobile=int(input('Enter Mobile number: '))
    email=input('Enter Email Id: ')

    dic["_id"]=id
    dic["empnm"]=empnm.lower()
    dic["dept"]=dept.lower()
    dic["post"]=post.lower()
    dic["city"]=city.lower()
    dic["salary"]=salary
    dic["mobile"]=mobile
    dic["email"]=email

    coll.insert_one(dic)
    print('Employee data is added')


except:
    print('unable to add the data')
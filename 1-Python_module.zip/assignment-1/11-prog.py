import mysql.connector as mycon
con=mycon.connect(host='localhost',user='root',password='akshata123',database='bookstoredb')
curs=con.cursor()

try:
    bcode=int(input('Enter bookcode: '))
    brev=input('Enter Book review: ')
    
    curs.execute("update books set review='%s' where bookcode=%d" %(brev,bcode))
    con.commit()
    result=curs.fetchone()
    
    print('Review data enterd successfully')
    
    
except:
    print('invalid input...')   
    

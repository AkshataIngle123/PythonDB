import mysql.connector as mycon
con=mycon.connect(host="localhost",user="root",password="akshata123",database="bookstoredb")
curs=con.cursor()

try:
    bcode=int(input('Enter bookcode: '))
    curs.execute("select * from books where bookcode=%d" %bcode)
    data=curs.fetchone()
    if data:
        print(data)
        d=input('Do you want to delete this data (yes|no): ')
        if d.lower().startswith('y'):
            curs.execute("delete from books where bookcode=%d" %bcode)
            con.commit()
            print('Book data deleted Successfully...')
        
    else:
        print('Book data not found')
except:
    print('enter valid bookcode...')
      
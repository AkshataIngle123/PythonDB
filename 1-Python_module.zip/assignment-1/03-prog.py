import mysql.connector as mycon
con=mycon.connect(host="localhost",user="root",password="akshata123",database="bookstoredb")
curs=con.cursor()

try:
    print('Adding New Book to the Table')
    bcode=int(input('Enter Bookcode: '))
    bnm=input('Enter Book Name: ')
    bauth=input('Enter Book Author Name: ')
    bpublic=input('Enter Book Publication Name: ')
    bedit=input('Enter Book Edition: ')
    bprice=float(input('Enter Price of the Book: '))
    bcatog=input('Enter Category of the Book: ')
except:
    print('You entered invalid input... Please give correct values')

curs.execute("insert into books values('%d','%s','%s','%s','%s','%f','%s')" %(bcode,bnm,bauth,bpublic,bedit,bprice,bcatog))
con.commit()
data=curs.fetchall()
if data:
    print(data)
con.close()



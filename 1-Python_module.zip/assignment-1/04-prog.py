import mysql.connector as mycon
con=mycon.connect(host='localhost',user='root', password='akshata123',database='bookstoredb')

curs=con.cursor()
curs.execute("select bookname from books")
result=curs.fetchall()
print('List of books')
for i in range(0,len(result)):
    print (i+1," ",result[i][0])

import mysql.connector as mycon
con=mycon.connect(host="localhost",user="root",password="akshata123",database="bookstoredb")
curs=con.cursor()

try:
    print('New Price of the particular book')
    bcode=int(input('Enter the Bookcode: '))
    newprice=float(input('Enter new price of the Book: '))

    curs.execute("update books set price='%s' where bookcode=%d" %(newprice,bcode))
    con.commit()
    data=curs.fetchone()
    if data:
        print('New Price Updated Successfully')
        print("Bookname      : ",data[1])
        print("Author        : ",data[2])
        print("Publication   : ",data[3])
        print("Edition Year  : ",data[4])
        print("Price         : ",data[5])
        print("Category      : ",data[6])
    else:
        print('unable to update the data')

except:
     print('enter valid input..')   





   
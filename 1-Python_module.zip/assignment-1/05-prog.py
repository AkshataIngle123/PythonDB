import mysql.connector as mycon
con=mycon.connect(host='localhost',user='root',password='akshata123',database='bookstoredb')
curs=con.cursor()

print('Searching Book From our Database')
try:
    bcode=int(input('Enter Bookcode: '))

    curs.execute("select * from books where bookcode=%s" %bcode)
    data=curs.fetchone()
    if data:
        print("Bookname      : ",data[1])
        print("Author        : ",data[2])
        print("Publication   : ",data[3])
        print("Edition Year  : ",data[4])
        print("Price         : ",data[5])
        print("Category      : ",data[6])
    else:
        print('Book data not found')
except:
    print('Enter Valid input....')

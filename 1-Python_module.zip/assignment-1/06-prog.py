import mysql.connector as mycon
con=mycon.connect(host='localhost',user='root',password='akshata123',database='bookstoredb')
curs=con.cursor()

print('List of particulat category')
bcatog=input('Enter catogory of the book: ')

curs.execute("select bookname from books where category='%s'" %bcatog)
data=curs.fetchmany()
if (data):
    print(data)
else:
    print('No books found of such Category')


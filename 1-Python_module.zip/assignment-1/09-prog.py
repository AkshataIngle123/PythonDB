import mysql.connector as mycon
con=mycon.connect(host='localhost',user='root',password='akshata123',database='bookstoredb')
curs=con.cursor()

bautho=input('Enter Author name: ')
bpublic=input('Enter publication name: ')
curs.execute("select * from books where author='%s' and publication='%s'" %(bautho,bpublic))
result=curs.fetchmany()
print(result)
